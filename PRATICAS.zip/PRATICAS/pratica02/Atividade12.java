/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade12;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade12 {

  


public class Academia {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int idade;
        char sexo;
        double mensalidade;
        System.out.print("Digite a idade do cliente: ");
        idade = entrada.nextInt();
        System.out.print("Digite o sexo do cliente (M/F): ");
        sexo = entrada.next().charAt(0);
        if (sexo == 'M') {
            if (idade <= 15) {
                mensalidade = 60.00;
            } else if (idade >= 16 && idade <= 18) {
                mensalidade = 75.00;
            } else if (idade >= 19 && idade <= 25) {
                mensalidade = 90.00;
            } else if (idade >= 26 && idade <= 40) {
                mensalidade = 85.00;
            } else {
                mensalidade = 80.00;
            }
        } else {
            if (idade <= 18) {
                mensalidade = 60.00;
            } else if (idade >= 19 && idade <= 30) {
                mensalidade = 90.00;
            } else if (idade >= 31 && idade <= 40) {
                mensalidade = 85.00;
            } else {
                mensalidade = 80.00;
            }
        }
        System.out.printf("A mensalidade a ser paga é R$ %.2f", mensalidade);
    }
}
    }
    

