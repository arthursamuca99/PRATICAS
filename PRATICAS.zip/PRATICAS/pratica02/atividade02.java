/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.pkg2;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    /**
     *
     */
    public class MediaAluno {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            System.out.print("Digite a primeira nota: ");
            double nota1 = input.nextDouble();
            
            System.out.print("Digite a segunda nota: ");
            double nota2 = input.nextDouble();
            
            double media = (nota1 + nota2) / 2;
            
            if (media >= 7) {
                System.out.println("Aprovado");
            } else {
                System.out.println("Reprovado");
            }
        }
    }
}
    }
    

