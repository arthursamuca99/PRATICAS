/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade13;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade13 {

  
public class Hotel {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String tipo;
        int dias;
        double total;
        System.out.print("Digite o tipo de apartamento (Simples/Duplo): ");
        tipo = entrada.nextLine();
        System.out.print("Digite a quantidade de dias: ");
        dias = entrada.nextInt();
        if (tipo.equalsIgnoreCase("Simples")) {
            if (dias < 10) {
                total = dias * 100.00;
            } else if (dias >= 10 && dias <= 15) {
                total = dias * 90.00;
            } else {
                total = dias * 80.00;
            }
        } else {
            if (dias < 10) {
                total = dias * 140.00;
            } else if (dias >= 10 && dias <= 15) {
                total = dias * 120.00;
            } else {
                total = dias * 100.00;
            }
        }
        System.out.printf("O total a ser pago é R$ %.2f", total);
    }
}
    }
    

