/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade10;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade10 {

   

public class OperacoesMatematicas {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double num1, num2, resultado;
        int opcao;
        System.out.print("Digite o primeiro número: ");
        num1 = entrada.nextDouble();
        System.out.print("Digite o segundo número: ");
        num2 = entrada.nextDouble();
        System.out.println("Escolha uma opção:");
        System.out.println("1 - Somar os dois números");
        System.out.println("2 - Multiplicar os dois números");
        System.out.println("3 - Subtrair o número maior pelo número menor");
        System.out.println("4 - Dividir o primeiro número pelo segundo");
        opcao = entrada.nextInt();
        switch (opcao) {
            case 1 -> {
                resultado = num1 + num2;
                System.out.printf("A soma dos números é %.2f", resultado);
            }
            case 2 -> {
                resultado = num1 * num2;
                System.out.printf("A multiplicação dos números é %.2f", resultado);
            }
            case 3 -> {
                if (num1 == num2) {
                    System.out.println("Os números são iguais, o resultado é zero.");
                } else if (num1 > num2) {
                    resultado = num1 - num2;
                    System.out.printf("A subtração do número maior pelo número menor é %.2f", resultado);
                } else {
                    resultado = num2 - num1;
                    System.out.printf("A subtração do número maior pelo número menor é %.2f", resultado);
                }
            }
            case 4 -> {
                if (num2 == 0) {
                    System.out.println("Não é possível dividir por zero.");
                } else {
                    resultado = num1 / num2;
                    System.out.printf("A divisão do primeiro número pelo segundo é %.2f", resultado);
                }
            }
            default -> System.out.println("Opção inválida!");
        }
    }
}
    }
    

