/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade08;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade08 {

   
     

public class Loja {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int codigo;
        double preco;
        System.out.print("Digite o código do produto: ");
        codigo = entrada.nextInt();
        switch (codigo) {
            case 1 -> {
                preco = 99.99;
                System.out.printf("O preço do sapato é R$ %.2f", preco);
            }
            case 2 -> {
                preco = 103.89;
                System.out.printf("O preço da bolsa é R$ %.2f", preco);
            }
            case 3 -> {
                preco = 49.98;
                System.out.printf("O preço da camisa é R$ %.2f", preco);
            }
            case 4 -> {
                preco = 89.72;
                System.out.printf("O preço da calça é R$ %.2f", preco);
            }
            case 5 -> {
                preco = 97.35;
                System.out.printf("O preço da blusa é R$ %.2f", preco);
            }
            default -> System.out.println("Código inválido!");
        }
    }
}
    }
    

