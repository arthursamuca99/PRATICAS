
    import javax.swing.JOptionPane;

public class joption2 {
    public static void main(String[] args) {
        String anoNascimentoStr = JOptionPane.showInputDialog("Digite o ano de nascimento:");
        int anoNascimento = Integer.parseInt(anoNascimentoStr);
        String anoAtualStr = JOptionPane.showInputDialog("Digite o ano atual:");
        int anoAtual = Integer.parseInt(anoAtualStr);
        int idadeAtual = anoAtual - anoNascimento;
        JOptionPane.showMessageDialog(null, "A idade da pessoa no ano atual é: " + idadeAtual);
        int idade2050 = 2050 - anoNascimento;
        JOptionPane.showMessageDialog(null, "A idade da pessoa em 2050 será: " + idade2050);
    }

    @Override
    public String toString() {
        return "joption2 []";
    }
}
    

