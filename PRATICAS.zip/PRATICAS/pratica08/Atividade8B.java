/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade8.b;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade8B {

  
       

public class Divisao {
    public static void main(String[] args) {
        Var eq = new Var();
        Scanner sc = new Scanner(System.in);
        int dividendo, divisor;
        double resultado;

        try {
            System.out.print("Digite o dividendo: ");
            dividendo = sc.nextInt();
            System.out.print("Digite o divisor: ");
            divisor = sc.nextInt();

            resultado = Var.dividir(dividendo, divisor);

            System.out.printf("Resultado: %.2f", resultado);

        } catch (ArithmeticException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Erro: entrada inválida!");
        } finally {
            sc.close();
        }
    }
}
 public class Var {
    public static double dividir(int dividendo, int divisor) throws ArithmeticException {
        if (divisor == 0) {
            throw new ArithmeticException("Não é possível dividir por zero!");
        }
        if (dividendo < 0) {
            throw new ArithmeticException("O dividendo não pode ser menor que zero!");
        }
        return (double) dividendo / divisor;
    }
}
    }
    

