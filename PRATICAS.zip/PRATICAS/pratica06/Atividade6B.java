/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade6.b;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade6B {

  

public class Numeros {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double[] numeros;
        numeros = new double;
        int[] posicoesNegativas;
        posicoesNegativas = new int;
        int contadorNegativos = 0;
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o " + (i+1) + "º número: ");
            numeros[i] = entrada.nextDouble();
            if (numeros[i] < 0) {
                posicoesNegativas[contadorNegativos] = i;
                contadorNegativos++;
            }
        }
        System.out.print("Vetor: [");
        for (int i = 0; i < 10; i++) {
            System.out.print(numeros[i]);
            if (i < 9) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
        if (contadorNegativos > 0) {
            System.out.print("Posições dos números negativos: [");
            for (int i = 0; i < contadorNegativos; i++) {
                System.out.print(posicoesNegativas[i]);
                if (i < contadorNegativos - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("]");
        } else {
            System.out.println("Não há números negativos no vetor.");
        }
    }
}
    }
    

