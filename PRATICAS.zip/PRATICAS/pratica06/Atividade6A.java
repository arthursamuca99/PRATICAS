/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade6.a;

import java.util.Scanner;

/**
 *
 * @author arthu
 */
public class Atividade6A {

 
        public class Numeros {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        var numeros = new int;
        int somaPares = 0;
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o " + (i+1) + "º número: ");
            numeros[i] = entrada.nextInt();
            if (numeros[i] % 2 == 0) {
                somaPares += numeros[i];
            }
        }
        System.out.print("Vetor: [");
        for (int i = 0; i < 10; i++) {
            System.out.print(numeros[i]);
            if (i < 9) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
        System.out.println("Soma dos números pares: " + somaPares);
    }
}
    }
    

